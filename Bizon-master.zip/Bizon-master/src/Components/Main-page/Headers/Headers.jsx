import React from 'react'
import Top_header from "./Top-header";
import Bottom_header from "./Bottom-header";

function Headers() {


    return (
        <section class="headers">
        <Top_header/>
        <Bottom_header/>
        </section>
    )
}

export default Headers
