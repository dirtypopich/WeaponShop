import React from 'react'
import About_company from "./About-company/About-company";
import Categoryes from "./Categoryes/Categoryes";


function Main_page() {
    return (
        <>
        <Categoryes />
        <About_company />
        </>
    )
}

export default Main_page
